<?php

defined('INTERNAL') || die();

$string['description'] = 'Tout le monde peut se connecter. À n\'utiliser que pour des tests !';
$string['title'] = 'Aucune';
