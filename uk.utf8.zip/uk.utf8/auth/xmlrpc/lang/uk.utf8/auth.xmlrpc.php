<?php

defined('INTERNAL') || die();

$string['authloginmsgtitle'] = 'Message de connexion erroné';
$string['description'] = 'Utiliser le service SSO d\'une application externe comme source d\'authentification';
$string['networkingdisabledonthissite'] = 'Le réseau est désactivé sur ce site';
$string['networkservers'] = 'Serveurs du réseau';
$string['notusable'] = 'Veuillez installer les extensions PHP XMLRPC, cURL et OpenSSL';
$string['title'] = 'XMLRPC';
$string['xmlrpcconfig'] = 'Configuration XML-RPC';
$string['youhaveloggedinfrom1'] = 'Retourner à <a href="%s">%s</a>';
