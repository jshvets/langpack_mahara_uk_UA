<?php

defined('INTERNAL') || die();

$string['description'] = 'Utiliser un serveur IMAP comme source d\'authentification';
$string['domainname'] = 'Nom du domaine des adresses électroniques';
$string['imapconfig'] = 'Configuration IMAP';
$string['notusable'] = 'Veuillez installer l\'extension IMAP de PHP';
$string['title'] = 'IMAP';
$string['weautocreateusers'] = 'Création automatique des utilisateurs sur Mahara';
