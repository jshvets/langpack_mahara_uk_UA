<?php

defined('INTERNAL') || die();

$string['description'] = 'Afficher les informations sur le groupe';
$string['title'] = 'Infos groupe';
