<?php

defined('INTERNAL') || die();

$string['description'] = 'Afficher la liste de vos contacts';
$string['numberoffriends'] = '(%s sur %s)';
$string['otherusertitle'] = 'Liste des contacts de %s';
$string['title'] = 'Mes contacts';
