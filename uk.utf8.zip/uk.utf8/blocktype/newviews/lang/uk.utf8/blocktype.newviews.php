<?php

defined('INTERNAL') || die();

$string['defaulttitledescription'] = 'Un titre par défaut sera affiché si vous ne saissiez pas la rubrique de titre';
$string['description2'] = 'Liste les dernières pages et collections qui ont été récemment modifiées et auxquelles vous avez accès.';
$string['title1'] = 'Modifications récentes';
$string['viewstoshow1'] = 'Nombre maximum de résultats à afficher';
$string['viewstoshowdescription'] = 'Entre 1 et 100';
