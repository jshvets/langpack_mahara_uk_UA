<?php

defined('INTERNAL') || die();

$string['Latest'] = 'Derniers inscrits';
$string['Random'] = 'Au hasard';
$string['defaulttitledescription'] = 'Un titre par défaut sera affiché si vous laissez la rubrique du titre vide';
$string['description'] = 'Afficher la liste des membres de ce groupe';
$string['options_numtoshow_desc'] = 'Le nombre de membres que vous désirez afficher.';
$string['options_numtoshow_title'] = 'Afficher membres';
$string['options_order_desc'] = 'Vous pouvez afficher les derniers membres du groupe ou un ensemble de membres choisis de manière aléatoire.';
$string['options_order_title'] = 'Ordre';
$string['show_all'] = 'Afficher tous les membres de ce groupe…';
$string['title'] = 'Membres du groupe';
