<?php

defined('INTERNAL') || die();

$string['collection'] = 'Collection';
$string['defaulttitledescription'] = 'Si vous laissez cette rubrique vide, le nom de la rubrique sera utilisé comme titre.';
$string['description'] = 'Afficher une collection de pages comme moyen de navigation dans votre portfolio';
$string['nocollections1'] = 'Aucune collection. <a href="%s">Créez-en une</a>.';
$string['title'] = 'Navigation';
