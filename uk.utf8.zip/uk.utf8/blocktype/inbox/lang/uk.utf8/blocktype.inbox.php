<?php

defined('INTERNAL') || die();

$string['More'] = 'Plus';
$string['defaulttitledescription'] = 'Un titre par défaut sera affiché si vous laissez la rubrique de titre vide';
$string['description'] = 'Affiche une sélection de messages reçus récemment';
$string['maxitems'] = 'Nombre maximum de messages à afficher';
$string['maxitemsdescription'] = 'Entre 1 et 100';
$string['messagetypes'] = 'Types de message à afficher';
$string['nomessages'] = 'Pas de messages';
$string['title'] = 'Ma boîte de réception';
