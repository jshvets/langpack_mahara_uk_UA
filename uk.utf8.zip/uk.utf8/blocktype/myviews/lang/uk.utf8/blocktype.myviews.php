<?php

defined('INTERNAL') || die();

$string['description1'] = 'Affiche tous les portfolios qui sont accessibles à la personne qui consulte votre profil';
$string['otherusertitle1'] = 'Portfolios de %s';
$string['title1'] = 'Mes portfolios';
