<?php

defined('INTERNAL') || die();

$string['defaulttitledescription'] = 'Un titre par défaut sera affiché si vous ne saisissez pas la rubrique de titre';
$string['description'] = 'Afficher les derniers messages sur les forums d\'un groupe';
$string['group'] = 'Groupe';
$string['nogroupstochoosefrom'] = 'Désolé il n\'y a pas de groupe à disposition';
$string['poststoshow'] = 'Nombre maximum de messages à afficher';
$string['poststoshowdescription'] = 'Entre 1 et 100';
$string['recentforumpostsforgroup'] = 'Messages récents pour %s';
$string['title'] = 'Derniers messages des forums du groupe';
