<?php

defined('INTERNAL') || die();

$string['appscodeorurl'] = 'Inclure le code ou l\'URL';
$string['appscodeorurldesc1'] = 'Consultez <a href="http://manual.mahara.org/en/%s/blocks/external.html#google-apps">la page</a> du manuel de l\'utilisateur de Mahara pour plus d\'informations sur la manière d\'inclure de contenu venant de Google. <br /> Collez le code <embed> ou l\'URL de la page où les applications de Google à inclure sont publiquement accessibles.';
$string['badurlerror'] = 'Incapable de comprendre le code d\'intégration ou l\'adresse URL: %s';
$string['description'] = 'Incorporer un calendrier ou des Google Documents';
$string['height'] = 'Hauteur';
$string['title'] = 'Applications Google';
