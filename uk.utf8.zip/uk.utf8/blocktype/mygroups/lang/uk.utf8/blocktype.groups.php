<?php

defined('INTERNAL') || die();

$string['description'] = 'Afficher la liste des groupes dont vous êtes membre';
$string['title'] = 'Mes groupes';
