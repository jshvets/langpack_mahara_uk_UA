<?php

defined('INTERNAL') || die();

$string['defaulttitledescription'] = 'Si vous ne donnez pas de titre, le nom de la rubrique sera affiché';
$string['description'] = 'Afficher une information du curriculum';
$string['fieldtoshow'] = 'Rubrique à afficher';
$string['filloutyourresume'] = '%sCompléter votre curriculum%s afin de saisir d\'autres rubriques !';
$string['noresumeitemselectone'] = 'Aucun élément du CV n\'est sélectionné';
$string['title'] = 'Rubrique du CV';
