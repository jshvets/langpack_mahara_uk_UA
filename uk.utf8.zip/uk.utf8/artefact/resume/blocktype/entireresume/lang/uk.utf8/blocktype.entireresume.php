<?php

defined('INTERNAL') || die();

$string['History'] = 'Histoire';
$string['address'] = 'Adresse';
$string['addresstag'] = 'Adresse : %s';
$string['description'] = 'Une manière rapide d\'afficher votre curriculum complet';
$string['noresumeselectone'] = 'Les éléments du CV seront affichés automatiquement ici';
$string['title'] = 'Mon CV complet';
