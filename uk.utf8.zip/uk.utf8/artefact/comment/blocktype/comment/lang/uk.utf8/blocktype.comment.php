<?php

defined('INTERNAL') || die();

$string['description'] = 'Un bloc pour afficher les commentaires';
$string['ineditordescription1'] = 'Les commentaires pour cette page seront affichés à cet emplacement au lieu du bas de la page.';
$string['title'] = 'Commentaires';
