<?php

defined('INTERNAL') || die();

$string['Files'] = 'Fichiers';
$string['description'] = 'Choisir les fichiers pouvant être téléchargés';
$string['title'] = 'Fichier(s) à télécharger';
