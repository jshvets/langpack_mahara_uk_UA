<?php

defined('INTERNAL') || die();

$string['description'] = 'Un simple fichier HTML de votre zone de fichiers';
$string['title'] = 'Code HTML';
