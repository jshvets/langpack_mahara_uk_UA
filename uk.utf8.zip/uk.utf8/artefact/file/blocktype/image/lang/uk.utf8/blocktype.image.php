<?php

defined('INTERNAL') || die();

$string['description'] = 'Une image de votre zone de fichiers';
$string['showdescription'] = 'Afficher la description ?';
$string['title'] = 'Image';
$string['width'] = 'Largeur';
$string['widthdescription1'] = 'Indiquez la largeur de votre image (en pixels). L\'image sera affichée à cette largeur. Laissez la rubrique vide si vous désirez afficher l\'image dans sa taille originale. Si la taille originale de l\'image est trop grande, l\'image sera ajustée à la largeur du bloc.';
