<?php

defined('INTERNAL') || die();

$string['description'] = 'Un document PDF de votre zone de gestion de fichiers';
$string['pdfwarning'] = 'Note : Afficher un gros PDF peut consommer beaucoup de ressources du navigateur web.';
$string['title'] = 'PDF';
