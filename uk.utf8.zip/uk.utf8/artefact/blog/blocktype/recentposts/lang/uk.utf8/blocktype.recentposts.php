<?php

defined('INTERNAL') || die();

$string['description'] = 'Afficher les articles les plus récents d\'un journal';
$string['itemstoshow'] = 'Articles à afficher';
$string['postedin'] = 'dans';
$string['postedon'] = 'le';
$string['title'] = 'Articles de journal récents';
$string['updatedon'] = 'Dernière mise à jour';
