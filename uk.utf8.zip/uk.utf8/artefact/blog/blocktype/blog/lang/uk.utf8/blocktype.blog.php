<?php

defined('INTERNAL') || die();

$string['defaulttitledescription'] = 'Si vous ne renseignez pas le titre, le nom du journal sera affiché';
$string['description'] = 'Un journal entier';
$string['postsperpage'] = 'Articles par page';
$string['title'] = 'Journal';
