<?php

defined('INTERNAL') || die();

$string['choosepublishedblogpostsdescription'] = 'Sélectionnez un des articles de journal que vous avez publiés';
$string['defaulttitledescription'] = 'Si vous ne renseignez pas le titre, le titre de l\'article sera affiché';
$string['description'] = 'Un article de votre journal (voir Contenu -> Journal)';
$string['title'] = 'Article du journal';
