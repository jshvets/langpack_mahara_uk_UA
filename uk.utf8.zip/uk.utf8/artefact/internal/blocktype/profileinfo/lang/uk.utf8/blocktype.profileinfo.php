<?php

defined('INTERNAL') || die();

$string['aboutme'] = 'À propos de moi';
$string['description'] = 'Choisissez les informations du profil à afficher';
$string['dontshowemail'] = 'Ne pas afficher l\'adresse de courriel';
$string['dontshowprofileicon'] = 'Ne pas afficher d\'image du profil';
$string['dontshowsocialprofiles'] = 'Masquer les réseaux sociaux';
$string['fieldstoshow'] = 'Rubriques à afficher';
$string['introtext'] = 'Introduction';
$string['noprofilesselectone'] = 'Aucun élément du profil n\'est sélectionné';
$string['showsocialprofiles'] = 'Afficher les réseaux sociaux';
$string['title'] = 'Information du profil';
$string['uploadaprofileicon'] = 'Vous n\'avez pas de photo dans votre profil. <a href="%sartefact/file/profileicons.php">Ajoutez-en une</a>.';
$string['useintroductioninstead'] = 'Vous pouvez utiliser plutôt la rubrique d\'introduction du profil en activant ceci et en laissant cette rubrique vide';
