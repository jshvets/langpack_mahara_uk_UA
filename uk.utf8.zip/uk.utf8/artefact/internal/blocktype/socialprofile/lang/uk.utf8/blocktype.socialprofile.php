<?php

defined('INTERNAL') || die();

$string['description'] = 'Sélectionnez l\'URL du réseaus social à afficher';
$string['displayaddressesas'] = 'Affichage des réseaux sociaux sous la forme de :';
$string['displaydefaultemail'] = 'Afficher l\'adresse de messagerie sous la forme d\'un bouton ?';
$string['displaymsgservices'] = 'Afficher les services de messagerie sous forme de boutons ?';
$string['displaysettings'] = 'Paramètres d\'affichage';
$string['noitemsselectone'] = 'Aucun média social n\'est sélectionné';
$string['optionicononly'] = 'boutons avec icônes';
$string['optiontexticon'] = 'boutons avec icônes et textes';
$string['optiontextonly'] = 'boutons avec textes';
$string['profilestoshow'] = 'Réseaux sociaux à afficher';
$string['title'] = 'Réseaux sociaux';
