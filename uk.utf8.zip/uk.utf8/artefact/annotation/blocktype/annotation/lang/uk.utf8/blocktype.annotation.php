<?php

defined('INTERNAL') || die();

$string['annotationreadonlymessage'] = 'L\'annotation n\'est plus modifiable une fois qu\'un commentaire a été fait sur celle-ci.';
$string['description'] = 'Un bloc qui vous permet d\'afficher vos annotations expliquant comment votre pièce, votre preuve, correspond à un standard de compétence.';
$string['title'] = 'Annotation';
